"""CLI conversation loop for supervised test-time fact memory."""

import sys

from src.llm.modules.online_memory import OnlineFactMemory


def run_online_chat(args, model) -> None:
    memory = OnlineFactMemory(model, args.online_memory_file)
    if args.prompt is None:
        print("Type /exit to quit, /remember TEXT to save facts, /memories to inspect, or /reset to clear.")
    while True:
        try:
            text = args.prompt if args.prompt is not None else input("You: ")
        except EOFError:
            break
        command = text.strip()
        if command in ("/exit", "/quit"):
            break
        if command == "/reset":
            args.online_memory_file.unlink(missing_ok=True)
            memory.reload()
            print("Memory cleared.")
        elif command == "/memories":
            facts = memory.recall_all()
            for fact in facts:
                print(f"{fact['question']} {fact['answer']}")
            if not facts:
                print("No facts could be recalled.")
        elif command == "/remember":
            print("Usage: /remember TEXT")
        else:
            explicit = command.startswith("/remember ")
            source = command.removeprefix("/remember ") if explicit else text
            written = memory.remember(source)
            if written.rejected:
                print("Some facts were not saved: " + "; ".join(written.rejected), file=sys.stderr)
            if explicit:
                print(f"Remembered {len(written.fact_ids)} fact(s).")
            else:
                answer = (
                    f"Remembered {len(written.fact_ids)} fact(s)."
                    if written.fact_ids and not text.rstrip().endswith("?")
                    else memory.answer(text, system=args.system, max_new_tokens=args.max_new_tokens)
                )
                if answer == "UNKNOWN":
                    answer = "I don't have a matching fact in memory."
                print(answer if args.prompt is not None else f"Assistant: {answer}")
        if args.prompt is not None:
            break
