"""Pilot: fit a next-token readout at test time on frozen Qwen features."""

import argparse
import json
from pathlib import Path
import time

import torch
from torch.nn import functional

from src.llm.helpers.dataset_generation import read_episodes
from src.llm.modules.qwen import Qwen35Wrapper


def prompt(model, question):
    return model.tokenizer.apply_chat_template(
        [
            {"role": "system", "content": "Answer with only the requested value."},
            {"role": "user", "content": question},
        ],
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )


@torch.no_grad()
def features(model, ids):
    tokens = torch.tensor([ids], device=model.device)
    return model.model.model(input_ids=tokens, use_cache=False).last_hidden_state[0].cpu().float()


def fit(keys, tokens):
    keys = functional.normalize(keys.double(), dim=-1)
    vocab, target = tokens.unique(return_inverse=True)
    targets = functional.one_hot(target, num_classes=len(vocab)).double()
    gram = keys @ keys.T
    dual = torch.linalg.solve(gram + 1e-4 * torch.eye(len(keys)), targets)
    return keys.float(), vocab, (keys.T @ dual).float()


@torch.no_grad()
def generate(model, question, state, mode):
    ids = model.tokenizer.encode(prompt(model, question), add_special_tokens=False)
    generated = []
    scores = []
    keys, vocab, weights, targets = state
    for _ in range(24):
        hidden = features(model, ids)[-1]
        query = functional.normalize(hidden, dim=-1)
        if mode == "ridge":
            score, index = (query @ weights).max(0)
            token = int(vocab[index])
        else:
            score, index = (query @ keys.T).max(0)
            token = int(targets[index])
        scores.append(float(score))
        if token == model.tokenizer.eos_token_id:
            break
        ids.append(token)
        generated.append(token)
    return model.tokenizer.decode(generated, skip_special_tokens=True).strip(), scores


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", default="mps")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    torch.set_num_threads(4)
    model = Qwen35Wrapper(device=args.device)
    rows = list(
        read_episodes(Path(".datasets_cache/session-broad-novel-values-v1/validation.jsonl"))
    )[:40:2]
    keys, labels = [], []
    started = time.monotonic()
    for row in rows:
        prefix = model.tokenizer.encode(prompt(model, row.question), add_special_tokens=False)
        answer = model.tokenizer.encode(row.answers[0], add_special_tokens=False)
        answer.append(model.tokenizer.eos_token_id)
        hidden = features(model, prefix + answer[:-1])[len(prefix) - 1 :]
        keys.append(hidden)
        labels.append(torch.tensor(answer))
    targets = torch.cat(labels)
    state = (*fit(torch.cat(keys), targets), targets)
    results = []
    for index, row in enumerate(rows):
        for mode in ("ridge", "nearest"):
            prediction, scores = generate(model, row.question, state, mode)
            result = {
                "id": row.id,
                "mode": mode,
                "question": row.question,
                "answer": row.answers[0],
                "prediction": prediction,
                "correct": prediction == row.answers[0],
                "scores": scores,
            }
            results.append(result)
            print(json.dumps({"i": index, **result}), flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(
            {
                "elapsed_seconds": time.monotonic() - started,
                "stored_facts": len(rows),
                "stored_tokens": len(targets),
                "results": results,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
