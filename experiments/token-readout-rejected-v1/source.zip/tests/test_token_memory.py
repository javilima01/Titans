from pathlib import Path
import tempfile
import unittest

import torch

from src.llm.modules.online_memory import OnlineFactMemory, grounded_facts, parse_json_array
from src.llm.modules.token_memory import TokenReadoutMemory

torch.set_num_threads(1)


class TokenMemoryTests(unittest.TestCase):
    def test_online_fit_correction_and_reload_preserve_other_facts(self):
        torch.manual_seed(83)
        keys = torch.randn(6, 16)
        memory = TokenReadoutMemory(backbone="test")
        first = memory.put("Tests for alpha?", keys[:3], torch.tensor([11, 22, 0]))
        second = memory.put("Entry for beta?", keys[3:], torch.tensor([33, 44, 0]))
        assert [memory.predict(key)[0] for key in keys] == [11, 22, 0, 33, 44, 0]
        memory.put("Tests for alpha?", keys[:3], torch.tensor([55, 66, 0]), replaces=first)
        assert memory.token_count == 6
        assert list(memory.facts) == [second, first]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "memory.safetensors"
            memory.save(path)
            restored = TokenReadoutMemory.load(path, backbone="test")
            assert path.stat().st_mode & 0o777 == 0o600
            assert [restored.predict(key)[0] for key in keys] == [55, 66, 0, 33, 44, 0]
            torch.testing.assert_close(restored.weights, memory.weights)
            with self.assertRaisesRegex(ValueError, "identity"):  # noqa: PT027
                TokenReadoutMemory.load(path, backbone="other")

    def test_failed_write_does_not_mutate_existing_state(self):
        memory = TokenReadoutMemory(backbone="test", max_tokens=2)
        keys = torch.eye(4)[:2]
        memory.put("Question?", keys, torch.tensor([7, 0]))
        before = memory.weights.clone()
        with self.assertRaisesRegex(ValueError, "capacity"):  # noqa: PT027
            memory.put("Another?", keys + 0.1, torch.tensor([8, 0]))
        torch.testing.assert_close(memory.weights, before)
        assert len(memory.facts) == 1
        with self.assertRaisesRegex(ValueError, "nonzero"):  # noqa: PT027
            memory.put("Question?", torch.zeros_like(keys), torch.tensor([7, 0]))

    def test_read_uses_weights_without_replaying_sources_or_target_examples(self):
        memory = TokenReadoutMemory(backbone="test")
        keys = torch.eye(3)
        memory.put("Name?", keys, torch.tensor([99, 33, 0]), source="My name is new.")
        memory.facts[0].targets.zero_()
        memory.facts[0].keys.zero_()
        assert [memory.predict(key)[0] for key in keys] == [99, 33, 0]

    def test_write_requires_grounded_answers_and_no_answer_in_question(self):
        raw = parse_json_array('```json\n[{"question":"My name?","answer":"Ilaria"}]\n```')
        accepted, rejected = grounded_facts(raw, "My name is Ilaria.")
        assert accepted == raw
        assert not rejected
        accepted, rejected = grounded_facts(
            [
                {"question": "Age?", "answer": "31"},
                {"question": "Timezone of Pacific/Chatham?", "answer": "Pacific/Chatham"},
                {"answer": "x"},
            ],
            "My timezone is Pacific/Chatham.",
        )
        assert not accepted
        assert len(rejected) == 3

    def test_questions_do_not_write_and_answers_must_be_recalled_values(self):
        memory = OnlineFactMemory.__new__(OnlineFactMemory)
        assert memory.remember("What is my name?").fact_ids == ()
        memory.recall_all = lambda: [{"id":0,"question":"Build tool?", "answer":"Ninja"}]
        memory.complete = lambda *args, **kwargs: "make build"
        assert memory.answer("Build tool?", system="") == "UNKNOWN"
        memory.complete = lambda *args, **kwargs: "ninja"
        assert memory.answer("Build tool?", system="") == "Ninja"


if __name__ == "__main__":
    unittest.main()
