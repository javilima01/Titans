"""Fact extraction, addressing and Qwen's supervised token-memory readout.

At write time, user statements supply answer labels. At read time, a question
index selects a canonical cue; the answer is generated from fitted weights.
Neither saved source text nor saved target tokens enters the read prompt.
"""

from dataclasses import dataclass
import hashlib
import json
import re
from typing import TYPE_CHECKING

import torch

from src.llm.modules.episodic_memory import SENTENCE_BOUNDARY
from src.llm.modules.token_memory import TokenReadoutMemory

if TYPE_CHECKING:
    from pathlib import Path

    from src.llm.modules.qwen import Qwen35Wrapper

EXTRACT = """Convert the user's factual statements into questions and answers for later recall.
Preserve the named subject, repository and property in each question. Use first person for user facts.
Answers must be exact substrings of the user's text. Do not make assumptions.
Return ONLY JSON: [{"question":"...", "answer":"..."}].
Return [] for questions, hypotheticals, small talk or requests with no stated fact.
"""
EXTRACTION_EXAMPLES = (
    (
        "Remember: I use the editor Helix.",
        '[{"question":"Which editor do I use?","answer":"Helix"}]',
    ),
    (
        "The deployment file for repo amber is ops/deploy.sh.",
        '[{"question":"What is the deployment file for repo amber?","answer":"ops/deploy.sh"}]',
    ),
    ("If my name were Kai, what would you call me?", "[]"),
)
ROUTE = """Select the stored questions whose answers would help answer the current
user request. Match the subject AND property. Include only relevant questions.
Do not select a different repository or person. Return ONLY a JSON array of integer
IDs, at most 3. Return [] when none match. You cannot see the stored answers.
"""
ROUTING_QUESTIONS = {
    "0": "What is my name?",
    "1": "What is the entry point for repo oak?",
    "2": "What is the build tool for repo fern?",
}
ROUTING_EXAMPLES = tuple(
    (json.dumps({"stored_questions": ROUTING_QUESTIONS, "request": request}), result)
    for request, result in (
        ("What should you call me?", "[0]"),
        ("Where does oak start?", "[1]"),
        ("What builds fern?", "[2]"),
        ("How old am I?", "[]"),
    )
)
MATCH = """Do these two questions request the same fact, or does the stored question
answer part of the request? Reply only yes or no. The entity (person/repository)
and the property must both match. Similar wording about different entities is no.
"""
MATCH_EXAMPLES = (
    (
        "Request: Where are oak docs?\nStored: What is the documentation directory for oak?",
        "yes",
    ),
    (
        "Request: Where are oak docs?\nStored: What is the test directory for oak?",
        "no",
    ),
    (
        "Request: Where are oak docs?\nStored: What is the documentation directory for pine?",
        "no",
    ),
    ("Request: What breed is my dog?\nStored: Which breed of dog do I have?", "yes"),
    ("Request: What breed is my dog?\nStored: What is my cat called?", "no"),
)
ANSWER_SYSTEM = "Answer with only the requested value."


def parse_json_array(text: str) -> list:
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip())
    result = json.loads(text)
    if not isinstance(result, list):
        msg = "Expected a JSON array"
        raise ValueError(msg)
    return result


def grounded_facts(raw: list, source: str) -> tuple[list[dict], list[str]]:
    """Reject invented answers, malformed records, and answer-bearing query keys."""
    accepted, rejected = [], []
    for fact in raw:
        if (
            not isinstance(fact, dict)
            or not isinstance(fact.get("question"), str)
            or not isinstance(fact.get("answer"), str)
            or not fact["question"].strip()
            or not fact["answer"].strip()
        ):
            rejected.append("Malformed question/answer record")
            continue
        question = fact["question"].strip().replace("your ", "my ").replace("the user's ", "my ")
        answer = fact["answer"].strip()
        if answer not in source:
            rejected.append("Extracted answer is not an exact span of the user message")
            continue
        if re.search(r"(?<!\w)" + re.escape(answer) + r"(?!\w)", question, re.IGNORECASE):
            rejected.append("Extracted question contains its answer")
            continue
        accepted.append({"question": question, "answer": answer})
    return accepted, rejected


@dataclass(frozen=True)
class MemoryWrite:
    fact_ids: tuple[int, ...]
    rejected: tuple[str, ...]


class OnlineFactMemory:
    """One user's/project's memory; the backbone remains frozen at all times."""

    def __init__(self, model: Qwen35Wrapper, path: Path):
        self.model = model
        self.path = path
        # Include tokenizer identity and prompt format: feature/label meanings must
        # stay identical across launches. This mode accepts the original backbone.
        identity = {
            "config": model.model.config.to_dict(),
            "vocabulary": model.tokenizer.get_vocab(),
            "chat_template": model.tokenizer.chat_template,
            "answer_system": ANSWER_SYSTEM,
            "format": 1,
        }
        self.backbone = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
        self.memory = TokenReadoutMemory.load(path, backbone=self.backbone)
        self.last_routes: list[dict] = []

    def reload(self) -> None:
        self.memory = TokenReadoutMemory.load(self.path, backbone=self.backbone)

    @torch.no_grad()
    def complete(
        self,
        instruction: str,
        content: str,
        *,
        examples: tuple = (),
        max_new_tokens: int = 384,
    ) -> str:
        messages = [{"role": "system", "content": instruction}]
        for user, assistant in examples:
            messages.extend(
                ({"role": "user", "content": user}, {"role": "assistant", "content": assistant})
            )
        messages.append({"role": "user", "content": content})
        text = self.model.tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True, enable_thinking=False
        )
        inputs = self.model.tokenizer(text, return_tensors="pt").to(self.model.device)
        output = self.model.model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
        return self.model.tokenizer.decode(
            output[0, inputs.input_ids.shape[1] :], skip_special_tokens=True
        ).strip()

    def prompt_ids(self, question: str) -> list[int]:
        text = self.model.tokenizer.apply_chat_template(
            [
                {"role": "system", "content": ANSWER_SYSTEM},
                {"role": "user", "content": question},
            ],
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
        return self.model.tokenizer.encode(text, add_special_tokens=False)

    @torch.no_grad()
    def features(self, ids: list[int]) -> torch.Tensor:
        tokens = torch.tensor([ids], device=self.model.device)
        hidden = self.model.model.model(input_ids=tokens, use_cache=False).last_hidden_state[0]
        return hidden.cpu().float()

    def teach(
        self, question: str, answer: str, *, source: str = "", replaces: int | None = None
    ) -> int:
        """Use a provided Q/A demonstration as supervised test-time training data."""
        prefix = self.prompt_ids(question)
        labels = self.model.tokenizer.encode(answer, add_special_tokens=False)
        if not labels or len(labels) > 127 or len(prefix) > 512:
            msg = "Require 1-127 answer tokens and a question prompt no longer than 512 tokens"
            raise ValueError(msg)
        labels.append(self.model.tokenizer.eos_token_id)
        keys = self.features(prefix + labels[:-1])[len(prefix) - 1 :]
        return self.memory.put(
            question, keys, torch.tensor(labels), source=source, replaces=replaces
        )

    def select(self, query: str) -> list[int]:
        """Address the question index without exposing answers to the router."""
        self.last_routes = []
        if not self.memory.facts:
            return []
        exact = [index for index, question in self.memory.questions.items() if query == question]
        if exact:
            return exact
        matched = []
        for index, question in self.memory.questions.items():
            response = self.complete(
                MATCH,
                f"Request: {query}\nStored: {question}",
                examples=MATCH_EXAMPLES,
                max_new_tokens=4,
            )
            self.last_routes.append({"id": index, "response": response})
            if re.match(r"yes\b", response, re.IGNORECASE):
                matched.append(index)
        return matched[:3]

    def remember(self, message: str) -> MemoryWrite:
        """Extract grounded user facts, fit the readout, then persist once per turn."""
        statements = [part for part in SENTENCE_BOUNDARY.split(message.strip())
                      if part.strip() and not part.rstrip().endswith("?")]
        if not statements:
            return MemoryWrite((), ())
        source = "\n".join(statements)
        if len(self.model.tokenizer.encode(source, add_special_tokens=False)) > 2048:
            msg = "Split memory writes into messages of at most 2048 tokens"
            raise ValueError(msg)
        response = self.complete(EXTRACT, source, examples=EXTRACTION_EXAMPLES)
        try:
            raw = parse_json_array(response)
        except ValueError:
            return MemoryWrite((), ("Model did not return a valid fact list",))
        facts, rejected = grounded_facts(raw, source)
        before = self.memory.facts, self.memory.weights, self.memory.vocabulary
        written = []
        try:
            for fact in facts:
                # Exact cues can be replaced. Differently worded facts stay in write
                # order so the answer decoder can attend to the newest value last.
                replaces = next((index for index, question in self.memory.questions.items()
                                 if question.casefold() == fact["question"].casefold()), None)
                question = self.memory.questions[replaces] if replaces is not None else fact["question"]
                index = self.teach(question, fact["answer"], source=message, replaces=replaces)
                written.append(index)
            if written:
                self.memory.save(self.path)
        except BaseException:
            self.memory.facts, self.memory.weights, self.memory.vocabulary = before
            raise
        return MemoryWrite(tuple(written), tuple(rejected))

    def recall(self, fact_id: int) -> str | None:
        """Decode from fast weights alone. Low confidence or failure to stop abstains."""
        question = self.memory.questions[fact_id]
        tokens = self.prompt_ids(question)
        generated = []
        for _ in range(128):
            hidden = self.features(tokens)[-1]
            token, score, margin = self.memory.predict(hidden)
            if score < 0.5 or margin < 0.2:
                return None
            if token == self.model.tokenizer.eos_token_id:
                return self.model.tokenizer.decode(generated, skip_special_tokens=True).strip()
            generated.append(token)
            tokens.append(token)
        return None

    def recalled_facts(self, query: str) -> list[dict]:
        result = []
        for index in self.select(query):
            answer = self.recall(index)
            if answer:
                result.append(
                    {"id": index, "question": self.memory.questions[index], "answer": answer}
                )
        return result

    def answer(self, query: str, *, system: str, max_new_tokens: int = 200) -> str:
        """Return an exact recalled value or UNKNOWN; this is a factual-recall API."""
        recalled = self.recall_all()
        if not recalled:
            return "UNKNOWN"
        instruction = (
            system
            + "\nUse the remembered facts when relevant. Later facts override earlier facts "
            "about the same subject. Copy the exact remembered answer value. "
            "If no remembered fact answers the question, reply UNKNOWN. Do not guess."
        )
        examples = tuple((fact["question"], fact["answer"]) for fact in recalled)
        response = self.complete(instruction, query, examples=examples, max_new_tokens=max_new_tokens)
        # A prompt alone did not prevent invented values in the 0.8B model.
        # Keep this recall endpoint extractive; applications can use recall_all
        # to supply facts to a separate, conversational answer generator.
        for fact in reversed(recalled):
            if response.casefold().strip() == fact["answer"].casefold():
                return fact["answer"]
        return "UNKNOWN"

    def recall_all(self) -> list[dict]:
        """Decode this bounded memory for Qwen to attend to, in last-write order."""
        result = []
        for index, question in self.memory.questions.items():
            answer = self.recall(index)
            if answer:
                result.append({"id": index, "question": question, "answer": answer})
        return result
