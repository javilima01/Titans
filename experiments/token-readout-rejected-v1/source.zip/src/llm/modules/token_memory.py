"""Supervised test-time memory connected directly to answer tokens.

Frozen decoder features X predict one-hot next tokens Y through a learned
linear readout: W = X.T @ solve(X @ X.T + ridge * I, Y). This is a closed-form
least-squares update at write time, not a Titans/HOPE hidden-state update.
Only tokens present in the memory need output columns. Stored feature/target
examples allow refitting on corrections without forgetting unrelated facts.
"""

from dataclasses import dataclass
import json
import math
from pathlib import Path
import tempfile

from safetensors import safe_open
from safetensors.torch import save_file
import torch
from torch.nn import functional


@dataclass(frozen=True)
class TokenFact:
    question: str
    source: str
    keys: torch.Tensor
    targets: torch.Tensor


class TokenReadoutMemory:
    """A bounded, per-scope fast readout, refitted only on explicit writes."""

    def __init__(self, *, backbone: str, ridge: float = 1e-4, max_tokens: int = 1024):
        if not backbone or not math.isfinite(ridge) or ridge <= 0 or max_tokens < 1:
            msg = "Require a backbone identity, positive finite ridge, and positive capacity"
            raise ValueError(msg)
        self.backbone = backbone
        self.ridge = ridge
        self.max_tokens = max_tokens
        self.facts: dict[int, TokenFact] = {}
        self.weights = torch.empty(0, 0)
        self.vocabulary = torch.empty(0, dtype=torch.long)

    @property
    def questions(self) -> dict[int, str]:
        return {index: fact.question for index, fact in self.facts.items()}

    @property
    def token_count(self) -> int:
        return sum(len(fact.targets) for fact in self.facts.values())

    def put(
        self,
        question: str,
        keys: torch.Tensor,
        targets: torch.Tensor,
        *,
        source: str = "",
        replaces: int | None = None,
    ) -> int:
        """Fit on one demonstrated answer plus retained facts, then commit atomically."""
        if (
            not question.strip()
            or keys.ndim != 2
            or targets.ndim != 1
            or keys.shape[0] != targets.shape[0]
            or not targets.numel()
            or not keys.shape[1]
            or targets.dtype != torch.long
            or (targets < 0).any()
            or not torch.isfinite(keys).all()
            or (keys.norm(dim=-1) == 0).any()
        ):
            msg = "Require a question and finite nonzero feature rows with nonnegative token IDs"
            raise ValueError(msg)
        if self.facts and keys.shape[1] != self.weights.shape[0]:
            msg = "Memory feature width does not match this decoder"
            raise ValueError(msg)
        if replaces is not None and replaces not in self.facts:
            msg = "Cannot replace a missing fact"
            raise ValueError(msg)
        identical = next(
            (index for index, fact in self.facts.items() if fact.question == question), None
        )
        if identical is not None and replaces is not None and identical != replaces:
            msg = "Question belongs to a different stored fact"
            raise ValueError(msg)
        index = replaces if replaces is not None else identical
        if index is None:
            index = max(self.facts, default=-1) + 1
        updated = dict(self.facts)
        updated.pop(index, None)
        updated[index] = TokenFact(
            question,
            source,
            functional.normalize(
                keys.detach().to(device="cpu", dtype=torch.float64), dim=-1
            ).float(),
            targets.detach().cpu().clone(),
        )
        if sum(len(fact.targets) for fact in updated.values()) > self.max_tokens:
            msg = f"Memory capacity ({self.max_tokens} answer tokens) exceeded; write not committed"
            raise ValueError(msg)
        features = torch.cat([fact.keys for fact in updated.values()]).double()
        labels = torch.cat([fact.targets for fact in updated.values()])
        vocabulary, columns = labels.unique(return_inverse=True)
        expected = functional.one_hot(columns, num_classes=len(vocabulary)).double()
        gram = features @ features.T
        gram.diagonal().add_(self.ridge)
        weights = (features.T @ torch.linalg.solve(gram, expected)).float()
        if not torch.isfinite(weights).all():
            msg = "Nonfinite memory fit; write not committed"
            raise ValueError(msg)
        fitted = features.float() @ weights
        if not torch.equal(vocabulary[fitted.argmax(-1)], labels):
            msg = "Memory readout cannot fit these facts without interference; write not committed"
            raise ValueError(msg)
        self.facts, self.weights, self.vocabulary = updated, weights, vocabulary
        return index

    def predict(self, hidden: torch.Tensor) -> tuple[int, float, float]:
        """Return next token, score and runner-up margin; never mutate memory."""
        if (
            not self.facts
            or hidden.ndim != 1
            or hidden.shape[0] != self.weights.shape[0]
            or not torch.isfinite(hidden).all()
        ):
            msg = "Need nonempty memory and one decoder feature of the correct width"
            raise ValueError(msg)
        query = functional.normalize(hidden.detach().cpu().float(), dim=-1)
        scores = query @ self.weights
        values, indices = scores.topk(min(2, len(scores)))
        margin = values[0] - values[1] if len(values) > 1 else values[0]
        return int(self.vocabulary[indices[0]]), float(values[0]), float(margin)

    def save(self, path: str | Path) -> None:
        """Store fitted weights and replay features together in an atomic private file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tensors = {"weights": self.weights, "vocabulary": self.vocabulary}
        records = []
        for index, fact in self.facts.items():
            tensors[f"keys.{index}"] = fact.keys
            tensors[f"targets.{index}"] = fact.targets
            records.append({"id": index, "question": fact.question, "source": fact.source})
        config = {
            "version": 1,
            "backbone": self.backbone,
            "ridge": self.ridge,
            "max_tokens": self.max_tokens,
            "facts": records,
        }
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
        try:
            temporary.chmod(0o600)
            save_file(tensors, temporary, metadata={"token_memory": json.dumps(config)})
            temporary.replace(path)
        finally:
            temporary.unlink(missing_ok=True)

    @classmethod
    def load(cls, path: str | Path, *, backbone: str) -> TokenReadoutMemory:
        path = Path(path)
        if not path.exists():
            return cls(backbone=backbone)
        with safe_open(path, framework="pt", device="cpu") as handle:
            config = json.loads((handle.metadata() or {}).get("token_memory", "{}"))
            if config.get("version") != 1 or config.get("backbone") != backbone:
                msg = "Token memory version or frozen-backbone identity does not match"
                raise ValueError(msg)
            memory = cls(backbone=backbone, ridge=config["ridge"], max_tokens=config["max_tokens"])
            memory.weights = handle.get_tensor("weights")
            memory.vocabulary = handle.get_tensor("vocabulary")
            expected_keys = {"weights", "vocabulary"}
            for record in config["facts"]:
                index = record["id"]
                if (
                    type(index) is not int
                    or index < 0
                    or index in memory.facts
                    or not isinstance(record["question"], str)
                    or not record["question"].strip()
                    or not isinstance(record["source"], str)
                ):
                    msg = "Invalid token-memory fact metadata"
                    raise ValueError(msg)
                keys, targets = (
                    handle.get_tensor(f"keys.{index}"),
                    handle.get_tensor(f"targets.{index}"),
                )
                if (
                    keys.ndim != 2
                    or targets.ndim != 1
                    or keys.shape != (len(targets), memory.weights.shape[0])
                    or not targets.numel()
                    or targets.dtype != torch.long
                    or (targets < 0).any()
                    or not torch.isfinite(keys).all()
                ):
                    msg = "Invalid token-memory feature tensors"
                    raise ValueError(msg)
                memory.facts[index] = TokenFact(record["question"], record["source"], keys, targets)
                expected_keys.update((f"keys.{index}", f"targets.{index}"))
            if (
                set(handle.keys()) != expected_keys
                or memory.weights.ndim != 2
                or memory.vocabulary.ndim != 1
                or memory.weights.shape[1] != len(memory.vocabulary)
                or memory.vocabulary.dtype != torch.long
                or (memory.vocabulary < 0).any()
                or len(memory.vocabulary.unique()) != len(memory.vocabulary)
                or not torch.isfinite(memory.weights).all()
                or memory.token_count > memory.max_tokens
            ):
                msg = "Invalid token-memory readout tensors"
                raise ValueError(msg)
        return memory
