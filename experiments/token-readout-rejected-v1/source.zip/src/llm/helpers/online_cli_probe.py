"""Check real process boundaries and user/project scope isolation."""

import argparse
import json
from pathlib import Path
import subprocess
import sys
import tempfile

CASES = (
    ("write_paths", "main", "/remember The startup file for repository maple is apps/api/launch.py. In repository maple, run tests with rye run pytest -k smoke.", None),
    ("ask_path", "main", "What is the startup file for repository maple?", "apps/api/launch.py"),
    ("ask_tests", "main", "How should I run tests in repository maple?", "rye run pytest -k smoke"),
    ("write_owner", "main", "Please remember: the release approver for repository maple is Nivalis-Orun.", None),
    ("ask_owner", "main", "Who is the release approver for repository maple?", "Nivalis-Orun"),
    ("correct_tests", "main", "Correction: in repository maple, run tests with hatch run test:unit.", None),
    ("ask_updated_tests", "main", "How should I run tests in repository maple?", "hatch run test:unit"),
    ("ask_retained_path", "main", "What is the startup file for repository maple?", "apps/api/launch.py"),
    ("ask_unknown", "main", "What is my favourite fruit?", "I don't have a matching fact in memory."),
    ("isolated_scope", "other", "What is the startup file for repository maple?", "I don't have a matching fact in memory."),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results = []
    with tempfile.TemporaryDirectory() as directory:
        for name, scope, prompt, expected in CASES:
            state = Path(directory)/f"{scope}.safetensors"
            command = [sys.executable,"main.py","chat","--device","mps","--online-memory-file",str(state),"--prompt",prompt,"--max-new-tokens","64"]
            process = subprocess.run(command, capture_output=True, text=True, check=False)
            if process.returncode:
                raise RuntimeError(process.stderr)
            prediction = process.stdout.strip()
            row = {"name":name,"scope":scope,"prompt":prompt,"expected":expected,"prediction":prediction,"correct":prediction == expected if expected is not None else None,"stderr":process.stderr,"memory_bytes":state.stat().st_size if state.exists() else 0}
            results.append(row)
            print(json.dumps({key:value for key,value in row.items() if key != "stderr"}), flush=True)
    scored = [row for row in results if row["correct"] is not None]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"cases":results,"correct":sum(row["correct"] for row in scored),"count":len(scored)}, indent=2)+"\n")


if __name__ == "__main__":
    main()
