"""End-to-end test-time fact writes, serialization, corrections and paraphrases."""

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import tempfile
import time

import torch

from src.llm.helpers.fact_extraction_probe import CASES, QUESTIONS
from src.llm.modules.online_memory import OnlineFactMemory
from src.llm.modules.qwen import Qwen35Wrapper

EXPECTED = [
    "Ilaria",
    "explanations with worked examples",
    "uv run pytest tests/api -q",
    "services/gateway/start.py",
    "Meson",
    "Ninja",
    "Pacific/Chatham",
    None,
    "append-only SQL files under db/changes",
]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="mps")
    parser.add_argument("--similarity-only", action="store_true")
    parser.add_argument("--answer-from-all", action="store_true")
    args = parser.parse_args()
    torch.set_num_threads(4)
    model = Qwen35Wrapper(device=args.device)
    started = time.monotonic()
    writes, reads = [], []
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "memory.safetensors"
        memory = OnlineFactMemory(model, path)
        for message in CASES:
            result = memory.remember(message)
            memory.reload()
            row = {"source": message, **asdict(result), "index": memory.memory.questions}
            writes.append(row)
            print(json.dumps(row), flush=True)
        for question, expected in zip(QUESTIONS, EXPECTED, strict=True):
            memory.reload()
            hidden = memory.features(memory.prompt_ids(question))[-1]
            query = hidden / hidden.norm()
            similarities = sorted(
                [
                    {"id": index, "score": float(query @ fact.keys[0]), "question": fact.question}
                    for index, fact in memory.memory.facts.items()
                ],
                key=lambda item: item["score"],
                reverse=True,
            )
            prediction = None
            if args.answer_from_all:
                recalled = memory.recall_all()
                prediction = memory.answer(question, system="Answer with only the exact remembered value, without explanation. If the value is unknown, reply UNKNOWN.", max_new_tokens=64)
            elif args.similarity_only:
                index = similarities[0]["id"]
                recalled = [
                    {
                        "id": index,
                        "question": memory.memory.questions[index],
                        "answer": memory.recall(index),
                    }
                ]
            else:
                recalled = memory.recalled_facts(question)
            values = [fact["answer"] for fact in recalled]
            row = {
                "question": question,
                "expected": expected,
                "recalled": recalled,
                "routes": memory.last_routes,
                "similarities": similarities,
                "prediction": prediction,
                "correct": (prediction == (expected or "UNKNOWN")) if args.answer_from_all else (values == [expected] if expected is not None else not values),
            }
            reads.append(row)
            print(json.dumps(row), flush=True)
        result = {
            "writes": writes,
            "reads": reads,
            "correct": sum(row["correct"] for row in reads),
            "count": len(reads),
            "memory_bytes": path.stat().st_size,
            "elapsed_seconds": time.monotonic() - started,
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        memory.memory.save(args.output.parent / "memory.safetensors")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
