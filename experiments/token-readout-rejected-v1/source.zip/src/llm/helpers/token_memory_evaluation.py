"""Reproduce supervised test-time Q/A storage with counterfactual corrections."""

import argparse
import json
from pathlib import Path
import tempfile
import time

import torch

from src.llm.helpers.dataset_generation import read_episodes
from src.llm.modules.online_memory import ANSWER_SYSTEM, OnlineFactMemory
from src.llm.modules.qwen import Qwen35Wrapper


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data",
        type=Path,
        default=Path(".datasets_cache/session-broad-novel-values-v1/validation.jsonl"),
    )
    parser.add_argument("--limit", type=int, default=40)
    parser.add_argument("--device", default="mps")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.limit < 2 or args.limit % 2 or args.output.exists():
        parser.error("Require an even limit >= 2 and a new output file")
    rows = list(read_episodes(args.data))[: args.limit]
    for left, right in zip(rows[::2], rows[1::2], strict=True):
        if left.question != right.question or left.metadata["pair_id"] != right.metadata["pair_id"]:
            parser.error("Need adjacent counterfactual pairs")
    torch.set_num_threads(4)
    model = Qwen35Wrapper(device=args.device)
    started = time.monotonic()
    baseline, results = {}, []
    with tempfile.TemporaryDirectory() as directory:
        memory = OnlineFactMemory(model, Path(directory) / "memory.safetensors")
        for row in rows[::2]:
            baseline[row.question] = memory.complete(ANSWER_SYSTEM, row.question, max_new_tokens=24)
        for variant in (0, 1):
            fact_ids = []
            for row in rows[variant::2]:
                fact_ids.append(
                    memory.teach(
                        row.question,
                        row.answers[0],
                        source="Supervised Q/A demonstration at test time",
                    )
                )
            memory.memory.save(memory.path)
            memory.reload()
            for fact_id, row in zip(fact_ids, rows[variant::2], strict=True):
                prediction = memory.recall(fact_id)
                result = {
                    "id": row.id,
                    "variant": variant,
                    "question": row.question,
                    "expected": row.answers[0],
                    "prediction": prediction,
                    "correct": prediction == row.answers[0],
                    "baseline": baseline[row.question],
                    "baseline_correct": baseline[row.question] == row.answers[0],
                }
                results.append(result)
                print(json.dumps(result), flush=True)
        memory.memory.weights.zero_()
        zeroed = [memory.recall(index) for index in fact_ids]
        result = {
            "data": str(args.data),
            "count": len(results),
            "correct": sum(row["correct"] for row in results),
            "baseline_correct": sum(row["baseline_correct"] for row in results),
            "all_zeroed_weights_abstain": all(value is None for value in zeroed),
            "zeroed_weight_predictions": zeroed,
            "facts_per_scope": len(memory.memory.facts),
            "stored_tokens": memory.memory.token_count,
            "memory_bytes": memory.path.stat().st_size,
            "elapsed_seconds": time.monotonic() - started,
            "predictions": results,
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
