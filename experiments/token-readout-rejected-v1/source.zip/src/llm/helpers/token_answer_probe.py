"""Compare answer prompts over facts decoded from an already saved fast readout."""

import argparse
import json
from pathlib import Path

from src.llm.helpers.fact_extraction_probe import QUESTIONS
from src.llm.helpers.online_memory_probe import EXPECTED
from src.llm.modules.online_memory import OnlineFactMemory
from src.llm.modules.qwen import Qwen35Wrapper


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    model = Qwen35Wrapper(device="mps")
    memory = OnlineFactMemory(model, args.state)
    recalled = memory.recall_all()
    facts = "\n".join(f"Question: {fact['question']}\nAnswer: {fact['answer']}" for fact in recalled)
    results = []
    for mode in ("qa_grounded",):
        for question, expected in zip(QUESTIONS, EXPECTED, strict=True):
            instruction = "Answer from the remembered facts only. Copy the exact answer value. If no remembered fact answers the question, reply UNKNOWN. Do not guess."
            content = f"Remembered facts, oldest to newest:\n{facts}\n\nCurrent question: {question}\nUse ONLY the facts above. Give only the exact answer, or UNKNOWN."
            if mode == "system_evidence":
                instruction += "\nRemembered facts:\n"+facts
                content = question + "\nUse ONLY remembered facts. Give only the exact answer, or UNKNOWN."
            examples = ()
            if mode == "qa_grounded":
                examples = tuple((fact["question"], fact["answer"]) for fact in recalled)
                content = question + "\nCopy the matching remembered answer exactly. If no memory answers this, reply UNKNOWN."
            prediction = memory.complete(instruction, content, examples=examples, max_new_tokens=64)
            row = {"mode":mode,"question":question,"expected":expected,"prediction":prediction,"correct":prediction == (expected or "UNKNOWN")}
            results.append(row)
            print(json.dumps(row), flush=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps({"state":str(args.state),"facts":recalled,"results":results}, indent=2)+"\n")


if __name__ == "__main__":
    main()
