"""Probe a frozen model's factual write and question-addressing decisions."""

import argparse
import json
from pathlib import Path
import re

import torch

from src.llm.modules.qwen import Qwen35Wrapper

EXTRACT = """Convert the user's factual statements into questions and answers for later recall.
Preserve the named subject, repository and property in each question. Use first person for user facts.
Answers must be exact substrings of the user's text. Do not make assumptions.
Return ONLY JSON: [{"question":"...", "answer":"..."}].
Return [] for questions, hypotheticals, small talk or requests with no stated fact.
"""

ROUTE = """Select the stored questions whose answers would help answer the current
user request. Match the subject AND property. Include only relevant questions.
Do not select a different repository or person. Return ONLY a JSON array of integer
IDs, at most 3. Return [] when none match. You cannot see the stored answers.
"""

CASES = [
    "Please remember: My name is Ilaria.",
    "I prefer explanations with worked examples.",
    "In repository kestrel, run tests with uv run pytest tests/api -q.",
    "The entry point for repository kestrel is services/gateway/start.py.",
    "The build tool for repository fern is Meson.",
    "For repository kestrel, use the build tool Bazel.",
    "Correction: the build tool for repository kestrel is Ninja.",
    "My timezone is Pacific/Chatham.",
    "Can you explain a linked list?",
    "Thanks, that was useful!",
    "If my name were Bob, what would you call me?",
    "The migration policy for kestrel is append-only SQL files under db/changes.",
]
QUESTIONS = [
    "What should you call me?",
    "How do I like things explained?",
    "Which command runs kestrel's API tests?",
    "Where does the kestrel service start?",
    "What builds fern?",
    "What builds kestrel now?",
    "What time zone do I use?",
    "What is my favourite fruit?",
    "Where do kestrel's database changes go, and can we edit old migrations?",
]


@torch.no_grad()
def complete(model, instruction, content):
    messages = [{"role": "system", "content": instruction}]
    if instruction == EXTRACT:
        messages.extend(
            [
                {"role": "user", "content": "Remember: I use the editor Helix."},
                {
                    "role": "assistant",
                    "content": '[{"question":"Which editor do I use?","answer":"Helix"}]',
                },
                {"role": "user", "content": "The deployment file for repo amber is ops/deploy.sh."},
                {
                    "role": "assistant",
                    "content": '[{"question":"What is the deployment file for repo amber?","answer":"ops/deploy.sh"}]',
                },
                {"role": "user", "content": "If my name were Kai, what would you call me?"},
                {"role": "assistant", "content": "[]"},
            ]
        )
    if instruction == ROUTE:
        stored = {
            "0": "What is my name?",
            "1": "What is the entry point for repo oak?",
            "2": "What is the build tool for repo fern?",
        }
        for request, answer in (
            ("What should you call me?", "[0]"),
            ("Where does oak start?", "[1]"),
            ("What builds fern?", "[2]"),
            ("How old am I?", "[]"),
        ):
            messages.extend(
                [
                    {
                        "role": "user",
                        "content": json.dumps({"stored_questions": stored, "request": request}),
                    },
                    {"role": "assistant", "content": answer},
                ]
            )
    messages.append({"role": "user", "content": content})
    text = model.tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True,
        enable_thinking=False,
    )
    inputs = model.tokenizer(text, return_tensors="pt").to(model.device)
    output = model.model.generate(**inputs, max_new_tokens=384, do_sample=False)
    return model.tokenizer.decode(
        output[0, inputs.input_ids.shape[1] :], skip_special_tokens=True
    ).strip()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    model = Qwen35Wrapper(device="mps")
    index = {}
    writes = []
    for source in CASES:
        result = complete(model, EXTRACT, source)
        row = {"source": source, "result": result}
        print(json.dumps(row), flush=True)
        writes.append(row)
        try:
            facts = json.loads(re.sub(r"^```(?:json)?\s*|\s*```$", "", result))
            for fact in facts:
                if fact["answer"] not in source:
                    continue
                key = fact.get("replaces")
                key = len(index) if key is None else key
                index[key] = fact["question"].replace("your ", "my ").replace("the user's ", "my ")
        except ValueError, KeyError, TypeError:
            continue
    reads = []
    for question in QUESTIONS:
        result = complete(
            model, ROUTE, json.dumps({"stored_questions": index, "request": question})
        )
        row = {"question": question, "result": result}
        print(json.dumps(row), flush=True)
        reads.append(row)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(
            {
                "index": index,
                "writes": writes,
                "reads": reads,
                "extract_instruction": EXTRACT,
                "route_instruction": ROUTE,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
